                                                                
 ____  _     _   _     _              _____     _               
|    \|_|___| |_|_|___| |_ ___ _ _   |   __|___| |_ _ _ ___ ___ 
|  |  | | -_| '_| | -_| . | . | | |  |__   | -_|  _| | | . |_ -|
|____/|_|___|_,_|_|___|___|___|_  |  |_____|___|_| |___|  _|___|
                              |___|                    |_|      
------------------------------------- Premium Scoreboard Config


(!)                                                      (!)
(!)  If you have any issues dont hesitate to contact us  (!)
(!)              discord.diekieboyy.com                  (!)
(!)                                                      (!)


Hello Customer,
Thanks for your purchase, we hope you like it.

Make sure to read the setup.txt file to see how to setup purchased your resource.