# oyna.zehircraft.com.tr World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Thu, 22 May 2025 15:53:45 +0300` (Timestamp: `1747918425471`)
- **Captured By**: `BabaYagaDX`

## Server
- **List Entry Name**: `Minecraft Sunucusu`
- **IP**: `oyna.zehircraft.com.tr`
- **Brand**: `Paper`
- **MOTD**: `Bağlantı sınanıyor...`
- **Version**: `1.21.4`
- **Protocol Version**: `769`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `5.180.104.183`
- **Port**: `25565`
- **Session ID**: `e821597c-4ade-4796-8455-235fe7cace34`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
